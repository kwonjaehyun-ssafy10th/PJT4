import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Snakes_and_Ladders {
    
    
    static int PlayerA;
    static int PlayerB;
    static int[] map = new int[101];
    static int turn;
    static boolean flag;
    
    public static void main(String[] args)throws IOException{
        
        System.out.println("게임을 시작합니다.");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        PlayerA =0;
        PlayerB =0;
        
        turn =0;
        
        
        
        
        map = makeMap();
        
        
        
        while (!flag) {
            ++turn;
            if (turn%2 == 1) {
                System.out.println(turn + "번 째 턴 A플레이어의 차례 입니다.");        
            }else {
                System.out.println(turn + "번 째 턴 B플레이어의 차례 입니다.");        
            }
            
            System.out.print("게임을 계속 진행 하시려면 1을 게임을 종료하시려면 2를 입력하세요 :");
            int input = Integer.parseInt(br.readLine());
            System.out.println("");

            if (input == 2) {
                System.out.println("게임을 종료합니다.");
                break;
            }

            System.out.println("주사위를 굴려 나온 수는 " + roll(turn) + " 입니다.");
            
            result(turn);
            showMap(map, PlayerA, PlayerB);
            System.out.println("");
            
        }
        
        
        
        
    }
    
    public static int roll(int turn) {
        int ran1 = (int)(Math.random()*6+1);
        int ran2 = (int)(Math.random()*6+1);
        
        int res = ran1+ran2;
        
        if (turn%2 == 1) {
            PlayerA += res;
            
        }else {
            PlayerB += res;
        }
        
        return res;
        
    }
    
    
    
    public static void result(int turn) {
        if (turn%2 == 1) {

            if (PlayerA >= 100) {
                PlayerA = 100;
                System.out.println("A플레이어가 승리하였습니다.");
                flag =true;
                return;
            }
            PlayerA = map[PlayerA] ;
            
            System.out.println("A플레이어가 " + PlayerA +"위치로 이동합니다");
            System.out.println("");
            
            if (PlayerA == PlayerB) {
                PlayerB = 0;
                System.out.println("A플레이어가 B플레이어를 잡았습니다.");
                System.out.println("");
            }
        }else {
            if (PlayerB >= 100) {
                PlayerB = 100;
                System.out.println("B플레이어가 승리하였습니다.");
                flag =true;
                return;
            }
            PlayerB = map[PlayerB] ;
            System.out.println("B플레이어가 " + PlayerB +"위치로 이동합니다");
            System.out.println("");
            if (PlayerA == PlayerB) {
                PlayerA = 0;
                System.out.println("B플레이어가 A플레이어를 잡았습니다.");
                System.out.println("");
            }
        }
        
        
        
        
    }
    
      // map 정보, PlayerA 위치, PlayerB 정보 넣으면 보드 출력하는 함수
    static void showMap(int[] map, int PlayerA, int PlayerB) {
        String[][] temp = new String[10][10];
        for (int i = 0; i < 100; i++) {
            if ((i / 10) % 2 == 0) temp[9 - (i / 10)][i % 10] = map[i + 1] + "";
            else temp[9- (i / 10)][9 - i % 10] = map[i + 1] + "";            
        }
        
        if (PlayerA != 0) {
            if ((PlayerA - 1) / 10 % 2 == 0) {
                temp[9 - (PlayerA - 1) / 10][(PlayerA - 1) % 10] = "A";
            } else {
                temp[9 - (PlayerA - 1) / 10][9 - (PlayerA - 1) % 10] = "A";
            }
        }
        
        if (PlayerB != 0) {
            if ((PlayerB - 1) / 10 % 2 == 0) {
                temp[9 - (PlayerB - 1) / 10][(PlayerB - 1) % 10] = "B";
            } else {
                temp[9 - (PlayerB - 1) / 10][9 - (PlayerB - 1) % 10] = "B";
            }
        }


        
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.printf("%-3s ", temp[i][j]);
            }
            System.out.println();
        }
    }
    
    static int[] makeMap() {
        Random random = new Random();
        
        int[] map = new int[101];
        for (int i = 1; i <= 100; i++) {
            map[i] = i;
        }
        
        int l = 8;
        int s = 8;
        
        int[][] ladders = new int[l][2];
        int[][] snakes = new int[s][2];
        List<Integer> used = new ArrayList<>();

        for (int i = 0; i < l; i++) {
            int n;
            while (true) {
                n = random.nextInt(80) + 1;
                if (!used.contains(n)) {
                    used.add(n);
                    break;
                }
            }
            while (true) {
                int m = random.nextInt(80) + 10;
                if (m - n > 10 && !used.contains(m)) {
                    ladders[i][0] = n; ladders[i][1] = m;
                    used.add(n); used.add(m);
                    break;
                }
            }
        }
        for (int i = 0; i < s; i++) {
            int n;
            while (true) {
                n = random.nextInt(80) + 20;
                if (!used.contains(n)) {
                    used.add(n);
                    break;
                }
            }        
            while (true) {
                int m = random.nextInt(80) + 10;
                if (n - m > 10 && !used.contains(m)) {
                    snakes[i][0] = n; snakes[i][1] = m;
                    used.add(n); used.add(m);
                    break;
                }
            }
        }
        
        for (int i = 0; i < l; i++) {
            map[ladders[i][0]] = map[ladders[i][1]];
        }
        
        for (int i = 0; i < s; i++) {
            map[snakes[i][0]] = map[snakes[i][1]];
        }
        
        return map;
    }
    
    
}